import express from "express";
const router = express.Router();
import { promises as fs } from "fs";

const { readFile, writeFile } = fs;
const app = express();

router.post("/", async (req, res) => {
    try {
        let account = req.body;
        const data = JSON.parse(await readFile("accounts.json"));  //para fazer a leitura //.parse para formatar 

        //vai criar um id e incrementar no account.jsn em um formato melhor
        account = {id: data.nextId++, ...account };

        //vai pegar o id e incluir no account
        data.accounts.push(account);

        //aqui o data modificado vai para o disco, lembra de formatar a "data" se não vai vir como objeto 
        await writeFile("accounts.json", JSON.stringify(data, null, 2));

        //para o usuário saber o id registrado
        res.send(account);
    } catch(err) {
        res.status(400).send({error: err.message} )
    }
});

export default router;