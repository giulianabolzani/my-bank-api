import express from "express";
import accountsRouter from "./routes/accounts.js";
import { promises as fs } from "fs";

const { readFile, writeFile } = fs;

const app = express();
app.use(express.json());

app.use("/account", accountsRouter);

app.listen(3000, async () => {
    try {
        await readFile("accounts.json");  //ler arquivo  //vai retornar promises
        console.log("API Started!"); 
    } catch (err) {  //se não existir vai cair aqui e criar a conta
        const initialJson = {  //verificar se existe a conta, se não, criar
            nextId: 1,   //incrementar +1 a cada req
            accounts: []
        }
        writeFile("accounts.json", JSON.stringify(initialJson)).then(() => {    //vai retornar promises
            console.log("API Started and File Created!");          
        }).catch(err => {     //se não for criado vai cair nesse erro e imprimir o log p gnt
            console.log(err);
        })   
    };
});